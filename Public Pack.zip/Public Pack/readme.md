# Insanity Resource

This is the resource pack for pause menu

## Credits

- [InsanityMC](insanityv20059)
    - Whole Pack

## Rules For Developers

- Keep the resource pack under 12MB
- If any new icons are over 128x128 they must be downscaled, just enough to decrease the file size a bit but still no noticable difference
- Only InsanityMC Must apporve changes

## Rules For Others

- Please be nice first time doing discord thing in corner hope you enjoy 
- feedback https://discord.gg/Quj89u3azV 
- website for other packs i will only do if i can 
- https://polecat-adapting-morally.ngrok-free.app/portfolio.html